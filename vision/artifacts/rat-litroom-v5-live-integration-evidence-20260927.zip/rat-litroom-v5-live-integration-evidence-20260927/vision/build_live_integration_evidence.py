#!/usr/bin/env python3
"""Seal the small V5 live plush-to-local-map integration evidence ZIP."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

VISION = Path(__file__).resolve().parents[2]
ROOT = VISION.parent
RUN = Path(__file__).resolve().parent
OBS = RUN / "live-observation-20260927-0049"
RELAY = RUN / "relay-one-20260927-045203"
NAME = "rat-litroom-v5-live-integration-evidence-20260927"
ZIP = VISION / "artifacts" / f"{NAME}.zip"
ONNX_SHA = "652a05e8c08aaee11a2b4d3c9ae4c737387bf8ffcac3372a4d83d0df7d80ed3d"
LOCK_SHA = "22ffcee2d241eb0c016d0a3ae5d178ef8d35e1f6541d1b20674f2c9a81237259"
FIRST_EVENT = "event_0001_2026-09-27T045203340Z.json"
FIRST_EVENT_SHA = "e16e83522a2f0e3e4bcffd28bc52d91b5fcbbe86201ccb8de754348af5a13bd2"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def add(files: dict[str, Path], source: Path, target: str) -> None:
    if not source.is_file() or source.is_symlink() or target in files or ".." in Path(target).parts:
        raise ValueError(f"missing/unsafe/duplicate evidence: {source} -> {target}")
    files[target] = source


def collect() -> dict[str, Path]:
    if sha256(RUN / "rat.onnx") != ONNX_SHA or sha256(RUN / "candidate_lock.json") != LOCK_SHA:
        raise ValueError("V5 model or lock differs from live observation")
    config = json.loads((OBS / "run_config.json").read_text())
    stats = json.loads((OBS / "run_stats.json").read_text())
    before = json.loads((OBS / "integration_before.json").read_text())
    after = json.loads((OBS / "integration_after.json").read_text())
    if (config.get("model_sha256") != ONNX_SHA or config.get("conf") != .7 or
            config.get("api_post") is not False or config.get("node_id") != "live-v5-observer" or
            config.get("h3") != "892a100d467ffff" or stats.get("events") != 6 or
            stats.get("frames_inferred") != 1346 or before["health"]["events"] != 1 or
            after["health"]["events"] != 2 or before["cell"]["score_b"] != .1297 or
            after["cell"]["score_b"] != .1618):
        raise ValueError("worker or API snapshots differ from reviewed live result")
    crop_json = sorted(OBS.glob("event_*.json"))
    crop_jpg = sorted(OBS.glob("event_*.jpg"))
    if len(crop_json) != 6 or len(crop_jpg) != 6:
        raise ValueError("expected six event JSON/JPEG pairs")
    if {p.stem for p in crop_json} != {p.stem for p in crop_jpg}:
        raise ValueError("event JSON/JPEG stems differ")
    if sha256(OBS / FIRST_EVENT) != FIRST_EVENT_SHA or sha256(RELAY / FIRST_EVENT) != FIRST_EVENT_SHA:
        raise ValueError("relayed event bytes differ from observed event")
    journal = [json.loads(line) for line in (RELAY / "relay_receipts.jsonl").read_text().splitlines()]
    if (len(journal) != 2 or [row["kind"] for row in journal] != ["attempt", "receipt"] or
            journal[0]["sha256"] != FIRST_EVENT_SHA or journal[1]["sha256"] != FIRST_EVENT_SHA or
            journal[1].get("outcome") != "accepted" or journal[1].get("accepted") is not True or
            journal[1].get("http_status") != 200 or journal[1].get("attempt") != 1):
        raise ValueError("relay journal is not the single accepted first event")
    files: dict[str, Path] = {}
    for path in (*crop_json, *crop_jpg):
        add(files, path, f"vision/live_observation/{path.name}")
    for name in ("run_config.json", "run_stats.json", "integration_before.json",
                 "integration_after.json", "integration_result.json", "frontend-live-event.png"):
        add(files, OBS / name, f"vision/live_observation/{name}")
    for name in (FIRST_EVENT, FIRST_EVENT.replace(".json", ".jpg"), "relay_receipts.jsonl"):
        add(files, RELAY / name, f"vision/one_event_relay/{name}")
    for name in ("live_worker.py", "event_relay.py", "live_bridge.py"):
        add(files, VISION / "pi" / name, f"vision/pi/{name}")
    for name in ("main.py", "store.py", "posterior.py"):
        add(files, ROOT / "api" / name, f"api/{name}")
    add(files, RUN / "candidate_lock.json", "vision/candidate_lock.json")
    add(files, Path(__file__), "vision/build_live_integration_evidence.py")
    add(files, VISION / "V5_LIVE_RESULTS.md", "RESULTS.md")
    return files


def verifier() -> bytes:
    return b'''#!/usr/bin/env python3
import hashlib
from pathlib import Path
root = Path(__file__).resolve().parent
lines = (root / "SHA256SUMS").read_text().splitlines()
seen = set()
for line in lines:
    expected, name = line.split("  ", 1)
    path = root / name
    if name in seen or not path.is_file() or path.is_symlink():
        raise SystemExit(f"Missing or duplicate file: {name}")
    seen.add(name)
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit(f"SHA256 mismatch: {name}")
print(f"Verified {len(lines)} files")
'''


def main() -> None:
    if ZIP.exists():
        raise SystemExit(f"refusing to overwrite: {ZIP}")
    files = collect()
    source_hashes = {
        "locked_v5_onnx_sha256": ONNX_SHA,
        "candidate_lock_sha256": LOCK_SHA,
        "existing_v5_development_zip_sha256": "5d4098dfea86dc80de230f9a689dad4ccdf819c194ac2ba5cdf96185bd5ca38e",
        "included_sources": {name: sha256(source) for name, source in sorted(files.items())
                             if name.startswith(("vision/pi/", "api/", "vision/candidate_lock"))},
        "pi_candidate_checksum_check": "pi_stage_expected.sha256 verified every staged file before the live observation",
        "model_weights_included": False,
    }
    generated = {
        "README.md": ("# V5 live integration evidence\n\n"
                      "One visible plush exposure produced six local crop events. Only the first "
                      "event was relayed to a loopback-only local API; it was accepted once. "
                      "See RESULTS.md, source_hashes.json, run statistics, API snapshots, and "
                      "the receipt journal. This is a demo integration check, not formal recall. "
                      "The V5 model weights are in the separate development candidate ZIP.\n\n"
                      "Run `python3 verify_bundle.py` after extraction.\n").encode(),
        "source_hashes.json": (json.dumps(source_hashes, indent=2) + "\n").encode(),
        "verify_bundle.py": verifier(),
    }
    checksums = {name: sha256(path) for name, path in files.items()}
    checksums.update({name: hashlib.sha256(data).hexdigest() for name, data in generated.items()})
    generated["SHA256SUMS"] = "".join(f"{digest}  {name}\n" for name, digest in
                                   sorted(checksums.items())).encode()
    with zipfile.ZipFile(ZIP, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(files.items()):
            archive.write(path, f"{NAME}/{name}")
        for name, data in sorted(generated.items()):
            archive.writestr(f"{NAME}/{name}", data)
    with zipfile.ZipFile(ZIP) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC check failed")
        expected = dict(line.split("  ", 1) for line in generated["SHA256SUMS"].decode().splitlines())
        for digest, name in expected.items():
            if hashlib.sha256(archive.read(f"{NAME}/{name}")).hexdigest() != digest:
                raise ValueError(f"ZIP SHA256 mismatch: {name}")
    print(f"{ZIP} bytes={ZIP.stat().st_size} sha256={sha256(ZIP)} "
          f"checked_files={len(checksums)}")


if __name__ == "__main__":
    main()
