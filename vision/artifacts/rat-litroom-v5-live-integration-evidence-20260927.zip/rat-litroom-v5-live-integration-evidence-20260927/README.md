# V5 live integration evidence

One visible plush exposure produced six local crop events. Only the first event was relayed to a loopback-only local API; it was accepted once. See RESULTS.md, source_hashes.json, run statistics, API snapshots, and the receipt journal. This is a demo integration check, not formal recall. The V5 model weights are in the separate development candidate ZIP.

Run `python3 verify_bundle.py` after extraction.
