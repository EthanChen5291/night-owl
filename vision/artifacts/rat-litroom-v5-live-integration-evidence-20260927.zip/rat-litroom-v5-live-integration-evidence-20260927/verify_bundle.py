#!/usr/bin/env python3
import hashlib
from pathlib import Path
root = Path(__file__).resolve().parent
lines = (root / "SHA256SUMS").read_text().splitlines()
seen = set()
for line in lines:
    expected, name = line.split("  ", 1)
    path = root / name
    if name in seen or not path.is_file() or path.is_symlink():
        raise SystemExit(f"Missing or duplicate file: {name}")
    seen.add(name)
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit(f"SHA256 mismatch: {name}")
print(f"Verified {len(lines)} files")
